﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WhileDoWhileExercise
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Tell me, What comes once in a minute, Twice in a moment,");
            Console.WriteLine("but never in a thousand years : ");


            string input = Console.ReadLine();

            while (!input.Equals("m" , StringComparison.OrdinalIgnoreCase))
            {
                Console.WriteLine("Try again");

                input = Console.ReadLine();
            }
            Console.WriteLine("\nYou got it, YAY!! ");

            Console.WriteLine("\nAnother one for you");
    


            string secondInput;

            do {
                Console.WriteLine("\nCan you name three consecutive days without using the words ");
                Console.WriteLine("Monday, Tuesday, Wednesday, Thursday,");
                Console.WriteLine("Friday, Saturday, or Sunday?");
                Console.WriteLine("\n");
                secondInput = Console.ReadLine();
            } while(!secondInput.Equals("yesterday, today and tomorrow" , StringComparison.InvariantCultureIgnoreCase));

            Console.WriteLine("\nYay! 2 out of 2, i will give you a piece of land\n");
        }
    }
}
