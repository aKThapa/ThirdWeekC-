﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SwitchCase
{

    class Program
    {
        static void Main(string[] args)
        {
     

            Console.WriteLine("Several people are standing for the presidency");
            Console.WriteLine("there are several candidates : ");
            Console.WriteLine("\n Hillary Clinton" );
            Console.WriteLine(" Donald Trump");
            Console.WriteLine(" Barrack Obama");

            Console.WriteLine("\nWho do you think will win : ");
            string input = Console.ReadLine();
           

            switch (input)
            {
                case "Hillary":
                case "hillary":
                case "Clinton":
                case "clinton":
                    Console.WriteLine("\nShe is just not bad, very bad ");
                    break;

                case "Donald":
                case "donald":
                case "Trump":
                case "trump":
                    Console.WriteLine("\nHe will possibly bring a doomsday ");
                    break;

                case "Barrack":
                case "barrack":
                case "Obama":
                case "obama":
                    Console.WriteLine("\nHe is not bad ");
                    break;
            }


            Console.WriteLine("\n");

        }
    }
}
