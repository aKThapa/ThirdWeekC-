﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArraysExercise
{
    //This program first gets 5 different user inputs and then stores them in an array
    //Then it adds up all the numbers and outputs the average

    //Secondly, it creates  5 x 5 2DArray
    //We have to populate each each elements in the 2D array ourselves
    //I decided to use the same user input and add +10 to every arrays in that index
    
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("************************************");
            Console.WriteLine("******This is the first part*******");
            Console.WriteLine("************************************\n");
            //This is the first bit
            //Declare an int array of length 5
            int[] inputs = new int[5];
            //declare a int total and initialise it 0
            //this will hold the value for the totals of the  user input
            int total = 0;
            Console.WriteLine("Enter 5 different numbers and i will give you the average");
            for (int i = 0; i < 5; i++)
            {
                inputs[i] = Int32.Parse(Console.ReadLine());
                //add inputs to the total
                total += inputs[i];// total = total + input
            }
            Console.WriteLine("\nYour Average is : " + (total / 5) + "\n");



            //This is the second part
            //Declare a 2D array of size 5 x 5
            Console.WriteLine("************************************");
            Console.WriteLine("******This is the second part*******");
            Console.WriteLine("************************************\n");
            Console.WriteLine("Now here i have declared a 2D array of size 5 x 5 and");
            Console.WriteLine("each element in the array has been filled with the same input");
            Console.WriteLine("as the one before, with just 10 added to it\n\n");

            int[,] twoDArrays = new int[5,5];//5 x 5 array 
            //declare secondTotals array, which will hold the 
            //totals for all the elements in each of the 2D array
            int[] secondTotals = new int[5];
            //get the user input from before and add 10 to them
            int addAmount = 10;
            //since we have 2D arrays now, we also need two for loops
            //to access every elements of the 2D arrays
            for (int i = 0; i < 5; i++)
            {
                //newTotal will hold the total for the elements in the sub array
                //in each index of the main array
                int newTotal = 0;
                for (int j = 0; j < 5; j++)
                {
                  twoDArrays[i, j] = (inputs[j] + addAmount);
                  newTotal += twoDArrays[i, j];
                }

                secondTotals[i] = newTotal;
                //we don't want all the sub arrays to have the same number
                //so I am increasing the amount, for every consecutive elements
                //in the main array
                //So, the first index will add 10 to every user input given before
                //Second index will add 20, then third 30, fourth 40, fifth 50
                addAmount += 10;
            }

            
            for (int i = 0; i < 5; i++)
            {
                for (int j = 1; j <= 1; j++)
                {
                    Console.WriteLine("At " + "[" + i + "]" + " we have : " + twoDArrays[i, 0] + " "
                                                                            + twoDArrays[i, 1] + " "
                                                                            + twoDArrays[i, 2] + " "
                                                                            + twoDArrays[i, 3] + " "
                                                                            + twoDArrays[i, 4] + "   Total =  "
                                                                            + secondTotals[i] + " & Avg : "
                                                                            + (secondTotals[i]/5));
                 }
                
            }


            Console.WriteLine("\n");


        }
    }
}
