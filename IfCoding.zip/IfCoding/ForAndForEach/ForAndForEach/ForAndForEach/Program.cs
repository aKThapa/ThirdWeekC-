﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ForAndForEach
{
    class Program
    {
        static void Main(string[] args)
        {
            //declare array of names for each seven dwarves
            string[] sevenDwarves = { "Happy", "Doc", "Sleepy", "Sneezy", "Dopey", "Bashful", "Grumpy" };
            Console.WriteLine("******************************");
            Console.WriteLine("First i am using the for loop");
            Console.WriteLine("******************************");
    

            //for loop
            for (int i = 0; i < 7; i++)
            {
                Console.WriteLine(sevenDwarves[i] + " your dinner is ready");
            }

            Console.WriteLine("\n");

            Console.WriteLine("******************************");
            Console.WriteLine("Now i am using the for each loop");
            Console.WriteLine("******************************");


            //for each
            foreach (string names in sevenDwarves )
            {
                Console.WriteLine(names + " your dinner is ready");
            }

            Console.WriteLine("******************************");
            Console.WriteLine("******************************");
            Console.WriteLine("\n");
            string[] mealAndDrink = new string[7];
             


            //for loop to ask for individual meal/drink
            for (int j = 0; j < 7; j++)
            {
                Console.WriteLine("\nWhat do you want for meal and dinner, " + sevenDwarves[j] + " ?\n");
                mealAndDrink[j] = Console.ReadLine(); 
            }

            Console.WriteLine("\n******************************");
            Console.WriteLine("******************************\n");
            //for loop to display their individuals meal/drink and their names
            for (int k = 0; k < 7; k++)
            {
                Console.WriteLine(sevenDwarves[k] + " your " + mealAndDrink[k] + " is ready!!!\n");
            }
        }
    }
}
