﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IfCodingExercise
{
    class Program
    {
        static void Main(string[] args)
        {
            int myNumber = 40;
            int input;
            int difference;

            Console.WriteLine("**********************************");
            Console.WriteLine("**** GUESS!!! MY NUMBER GAME  ****");
            Console.WriteLine("**  I have thought of a number **");
            Console.WriteLine("***  it's between 1 and 100   ***");
            Console.WriteLine("All you have to do is try guess it");
            Console.WriteLine("**********************************");
            Console.WriteLine("**********************************");
            Console.WriteLine("**********************************");
            Console.WriteLine("**********************************");
            Console.WriteLine("**********************************");
            Console.WriteLine("\n\n\nYour Guess : ");

            //console read line takes input as a string 
            //so we need to convert it to to an int
       

            do
            {
                input = Int32.Parse(Console.ReadLine());
                difference = input - myNumber;
                //Console.WriteLine("Difference = " + difference);
                if (difference > 50 && difference > 0)
                {
                    Console.WriteLine("Your guess is TOO big\n");
                }
                if (difference <= 50 && difference > 20 && difference > 0)
                {
                    Console.WriteLine("It's a BIG guess\n");
                }
                if (difference <= 20 && difference > 10 && difference > 0)
                {
                    Console.WriteLine("You guessed a greater number\n");
                }
                if (difference <= 10 && difference > 5 && difference > 0)
                {
                    Console.WriteLine("Your guess is greater but not too far away now\n");
                }
                if (difference <= 5 && difference > 0 )
                {
                    Console.WriteLine("Your guess is greater but you are very very close\n");
                }

                if (difference < 0)
                {
                    Console.WriteLine("Your guess is too small\n");
                }
                if (difference != 0)
                {
                    Console.WriteLine("\nGuess again : ");
                }

            } while (difference != 0);

            Console.WriteLine("\n\nWell done! You have got it right\n");

            //int myNumber = 50;
            //Console.WriteLine("\n\nHello , World");
        }
    }
}
